package Management.com.example.Bicycle;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BicycleApplicationTests {

	@Test
	void contextLoads() {
	}

}
