package Management.com.example.Bicycle.controller;

import Management.com.example.Bicycle.model.SessionUser ;
import Management.com.example.Bicycle.model.UserSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import Management.com.example.Bicycle.service.UserService;  // Example service to handle user logic

@Controller
public class PageController {

    @Autowired
    private UserService userService;  // Your service to handle user authentication

    // Display the homepage when visiting '/'
    @GetMapping({"/"})
    public String index() {
        UserSession.clearSession(); // Clear the session user when accessing "/"
        return "index";
    }

    // Check if user is authenticated
    private boolean isAuthenticated() {
        return UserSession.getSessionUser () != null;
    }

    // Redirect to login if not authenticated
    private String checkAuthentication() {
        if (!isAuthenticated()) {
            return "redirect:/log_in"; // Redirect to login if not logged in
        }
        return null; // No redirection needed
    }

    // Display 'about us' page
    @GetMapping("/about_us")
    public String aboutUs(Model model) {
        String redirect = checkAuthentication();
        if (redirect != null) return redirect;
        return "about_us";
    }

    // Admin page
    @GetMapping("/admin")
    public String adminPage(Model model) {
        return "admin";
    }

    // Booking page
    @GetMapping("/booking")
    public String booking(Model model) {
        String redirect = checkAuthentication();
        if (redirect != null) return redirect;
        return "booking";
    }

    // Contact Us page
    @GetMapping("/contact_us")
    public String contactUs(Model model) {
        String redirect = checkAuthentication();
        if (redirect != null) return redirect;
        return "contact_us";
    }

    // Edit page
    @GetMapping("/edit")
    public String editPage(Model model) {
        String redirect = checkAuthentication();
        if (redirect != null) return redirect;
        return "edit";
    }

    // Home page
    @GetMapping("/home")
    public String home(Model model) {
        String redirect = checkAuthentication();
        if (redirect != null) return redirect;
        return "home";
    }

    // Information page
    @GetMapping("/info")
    public String infoPage(Model model) {
        return "info";
    }

    // Login page
    @GetMapping("/log_in")
    public String login() {
        return "log_in"; // This will display the sign-in form
    }

    // News page
    @GetMapping("/news")
    public String newsPage(Model model) {
        String redirect = checkAuthentication();
        if (redirect != null) return redirect;
        return "news";
    }

    // Review page
    @GetMapping("/review")
    public String review(Model model) {
        String redirect = checkAuthentication();
        if (redirect != null) return redirect;
        return "review";
    }
    // Payment page
    @GetMapping("/payment")
    public String payment(Model model) {
        String redirect = checkAuthentication();
        if (redirect != null) return redirect;
        return "payment";
    }


    // History page
    @GetMapping("/history")
    public String historyPage(Model model) {
        String redirect = checkAuthentication();
        if (redirect != null) return redirect;
        return "history";
    }

    // Student page
    @GetMapping("/student")
    public String studentPage(Model model) {
        SessionUser  sessionUser  = UserSession.getSessionUser ();
        if (sessionUser  != null) {
            model.addAttribute("fullName", sessionUser .getFullName());
            model.addAttribute("email", sessionUser .getEmail());
            model.addAttribute("studentId", sessionUser .getStudentId()); // Student ID
            model.addAttribute("id", sessionUser .getId()); // User ID
        } else {
            return "redirect:/log_in"; // Redirect to login if not logged in
        }
        return "student"; // Return the student page
    }

    // Timer page
    @GetMapping("/timer")
    public String timerPage(Model model) {
        String redirect = checkAuthentication();
        if (redirect != null) return redirect;
        return "timer";
    }

    // Handle login submission (post request)
    @PostMapping("/log_in")
    public String handleLogin(@RequestParam String email, @RequestParam String password, Model model) {
        // Authenticate the user
        boolean isAuthenticated = userService.authenticateUser (email, password);  // Assuming a service method

        if (isAuthenticated) {
            return "redirect:/home";  // Redirect to the home page after successful login
        } else {
            model.addAttribute("error", "Invalid credentials, please try again.");  // Error message for failed login
            return "log_in";  // Show login page with error message
        }
    }
}
