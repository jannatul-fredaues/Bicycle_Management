package Management.com.example.Bicycle.model;

import jakarta.persistence.*;
import java.text.SimpleDateFormat;
import java.util.Date;

@Entity
@Table(name = "ride_history")
public class RideHistory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String email;  // Fetched from session
    private String startTime;
    private String endTime;
    private int rideTime;
    private int payment;

    private static final int RATE = 10; // 10 Taka per 10 minutes

    public RideHistory() {}

    public RideHistory(String email) {
        this.email = email;
        this.startTime = new SimpleDateFormat("HH:mm dd/MM/yyyy").format(new Date());
    }

    public void setEndTime() {
        this.endTime = new SimpleDateFormat("HH:mm dd/MM/yyyy").format(new Date());
        calculateRideTimeAndPayment();
    }

    private void calculateRideTimeAndPayment() {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("HH:mm dd/MM/yyyy");
            Date start = sdf.parse(startTime);
            Date end = sdf.parse(endTime);
            long diffInMillis = end.getTime() - start.getTime();

            // Calculate ride time in minutes — always round UP for started minute
            this.rideTime = Math.max(1, (int) Math.ceil(diffInMillis / (1000.0 * 60)));

            // Payment is 1 Taka per started minute
            this.payment = rideTime;

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public Long getId() { return id; }
    public String getEmail() { return email; }
    public String getStartTime() { return startTime; }
    public String getEndTime() { return endTime; }
    public int getRideTime() { return rideTime; }
    public int getPayment() { return payment; }
}