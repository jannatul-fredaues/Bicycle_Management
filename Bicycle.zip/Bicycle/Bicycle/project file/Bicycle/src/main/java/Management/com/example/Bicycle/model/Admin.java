//package Management.com.example.Bicycle.model;
//
//import java.util.ArrayList;
//import java.util.List;
//
//class Admin {
//    private String adminName;
//    private String adminId;
//    private String adminEmail;
//    private String adminPassword;
//    private static List<User> users = new ArrayList<>();
//
//    public Admin(String name, String id, String email, String password) {
//        this.adminName = name;
//        this.adminId = id;
//        this.adminEmail = email;
//        this.adminPassword = password;
//    }
//
//    public String getAdminName() { return adminName; }
//    public String getAdminId() { return adminId; }
//    public String getAdminEmail() { return adminEmail; }
//    public boolean validatePassword(String inputPassword) { return adminPassword.equals(inputPassword); }
//
//    public void addUser(User user) {
//        users.add(user);
//    }
//
//    public List<User> getAllUsers() {
//        return users;
//    }
//}