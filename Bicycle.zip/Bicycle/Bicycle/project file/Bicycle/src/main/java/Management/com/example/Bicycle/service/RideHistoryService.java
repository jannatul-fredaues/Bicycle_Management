package Management.com.example.Bicycle.service;

import Management.com.example.Bicycle.model.RideHistory;
import Management.com.example.Bicycle.model.UserSession;
import Management.com.example.Bicycle.repository.RideHistoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class RideHistoryService {

    @Autowired
    private RideHistoryRepository rideHistoryRepository;

    public RideHistory startRide() {
        if (UserSession.getSessionUser() == null) {
            throw new IllegalStateException("User not logged in.");
        }

        RideHistory ride = new RideHistory(UserSession.getSessionUser().getEmail());
        return rideHistoryRepository.save(ride);
    }

    public RideHistory stopRide(Long rideId) {
        Optional<RideHistory> optionalRide = rideHistoryRepository.findById(rideId);
        if (optionalRide.isPresent()) {
            RideHistory ride = optionalRide.get();
            ride.setEndTime();
            return rideHistoryRepository.save(ride);
        }
        throw new IllegalArgumentException("Ride ID not found.");
    }

    public List<RideHistory> getUserHistory() {
        if (UserSession.getSessionUser() == null) {
            throw new IllegalStateException("User not logged in.");
        }
        return rideHistoryRepository.findByEmail(UserSession.getSessionUser().getEmail());
    }
}
