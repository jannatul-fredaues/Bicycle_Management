package Management.com.example.Bicycle.service;

import Management.com.example.Bicycle.model.User;
import Management.com.example.Bicycle.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    // Save user with encrypted password
    public void saveUser(User user, String password) {
        // Set the password and save the user to the database
        user.setPassword(passwordEncoder.encode(password)); // Encrypt the password
        userRepository.save(user); // Save the user to the database
    }

    // Find user by email
    public Optional<User> findByEmail(String email) {
        return userRepository.findByEmail(email);
    }

    // Check if the password is correct
    public boolean checkPassword(User user, String password) {
        System.out.println("Comparing: " + passwordEncoder.encode(password) + " with " + user.getPassword());
        return passwordEncoder.matches(password, user.getPassword());
    }


    // Save or update user information (for cases where the user already exists)
    public void updateUser (User user) {
        // Check if the user exists
        if (user.getId() != null && userRepository.existsById(user.getId())) {
            // If the password is not null or empty, encrypt it before saving
            if (user.getPassword() != null && !user.getPassword().isEmpty()) {
                user.setPassword(passwordEncoder.encode(user.getPassword())); // Encrypt the password
            }
            userRepository.save(user); // Save updated user
        }
    }

    // Authenticate the user by checking email and password
    public boolean authenticateUser(String email, String password) {
        // Fetch the user by email
        Optional<User> user = userRepository.findByEmail(email);

        // Check if the user exists and if the password matches
        if (user.isPresent() && passwordEncoder.matches(password, user.get().getPassword())) {

            return true;  // Authentication successful
        }
        return false;  // Authentication failed
    }
}
