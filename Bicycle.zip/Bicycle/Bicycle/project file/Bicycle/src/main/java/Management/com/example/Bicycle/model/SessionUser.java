// SessionUser .java
package Management.com.example.Bicycle.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SessionUser  {

    private Long id;
    private String fullName;
    private String email;
    private String studentId;

    // Constructors
    public SessionUser () {}

    public SessionUser (Long id, String fullName, String email, String studentId) {
        this.id = id;
        this.fullName = fullName;
        this.email = email;
        this.studentId = studentId;
    }


}