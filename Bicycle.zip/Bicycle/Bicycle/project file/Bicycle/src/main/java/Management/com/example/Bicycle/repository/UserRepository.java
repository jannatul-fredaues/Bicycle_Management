package Management.com.example.Bicycle.repository;

import Management.com.example.Bicycle.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {

    // Find a user by email (you can use this method for login functionality)
    Optional<User> findByEmail(String email);

    // Check if a user exists by email
    boolean existsByEmail(String email);

    // Find a user by student ID (optional, in case you want to support login with student ID)
    Optional<User> findByStudentId(String studentId);
}
