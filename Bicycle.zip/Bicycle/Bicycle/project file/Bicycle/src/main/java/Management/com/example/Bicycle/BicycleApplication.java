package Management.com.example.Bicycle;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BicycleApplication {

	public static void main(String[] args) {
		SpringApplication.run(BicycleApplication.class, args);
	}

}
