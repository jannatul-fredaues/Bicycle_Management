package Management.com.example.Bicycle.repository;

import Management.com.example.Bicycle.model.RideHistory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface RideHistoryRepository extends JpaRepository<RideHistory, Long> {
    List<RideHistory> findByEmail(String email);  // Fetch ride history by user email
}
