package Management.com.example.Bicycle.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Getter
@Entity
@Table(name = "users")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Setter
    @Column(name = "full_name", nullable = false)
    private String fullName;

    @Setter
    @Column(name = "student_id", nullable = false, unique = true)
    private String studentId;

    @Setter
    @Column(name = "email", nullable = false, unique = true)
    private String email;

    @Setter
    @Column(name = "password", nullable = false)
    private String password;

    // Constructors
    public User() {}

    public User(String fullName, String email, String password, String studentId) {
        this.fullName = fullName;
        this.email = email;
        this.password = password;
        this.studentId = studentId;
    }
}
