package Management.com.example.Bicycle.controller;

import Management.com.example.Bicycle.model.User;
import Management.com.example.Bicycle.model.SessionUser;
import Management.com.example.Bicycle.model.UserSession;
import Management.com.example.Bicycle.service.UserService;
import Management.com.example.Bicycle.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/auth")
public class UserController {

    @Autowired
    private UserService userService;

    @Autowired
    private UserRepository userRepository;

    // Endpoint for user registration
    @PostMapping("/signup")
    public ResponseEntity<Map<String, String>> registerUser(@RequestBody User user) {
        Map<String, String> response = new HashMap<>();

        // Check if email already exists
        if (userRepository.existsByEmail(user.getEmail())) {
            response.put("error", "Email is already taken.");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
        }

        // Check if student ID already exists
        if (userRepository.findByStudentId(user.getStudentId()).isPresent()) {
            response.put("error", "Registration Number is already in use.");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
        }

        // Save user
        userService.saveUser(user, user.getPassword());
        response.put("message", "Registration successful!");
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    // UserController.java
    @PostMapping("/signin")
    public ResponseEntity<Map<String, String>> loginUser (@RequestBody User user) {
        Optional<User> existingUser  = userRepository.findByEmail(user.getEmail());

        Map<String, String> response = new HashMap<>();
        if (existingUser .isPresent()) {
            if (userService.checkPassword(existingUser .get(), user.getPassword())) {
                response.put("message", "Login successful");
                // Create SessionUser  and store it in a static variable
                SessionUser  sessionUser  = new SessionUser (
                        existingUser .get().getId(), // User ID
                        existingUser .get().getFullName(),
                        existingUser .get().getEmail(),
                        existingUser .get().getStudentId() // Student ID
                );
                UserSession.setSessionUser (sessionUser ); // Store in a static session holder
                return ResponseEntity.ok(response);
            } else {
                response.put("error", "Wrong Password");
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(response);
            }
        } else {
            response.put("error", "User  not found");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
        }
    }
    @PutMapping("/updateProfile")
    public ResponseEntity<Map<String, String>> updateProfile(@RequestBody User updatedUser ) {
        Map<String, String> response = new HashMap<>();

        // Retrieve the current session user
        SessionUser  sessionUser  = UserSession.getSessionUser ();

        if (sessionUser  == null) {
            response.put("error", "User  not logged in.");
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(response);
        }

        // Find the existing user in the database
        Optional<User> optionalUser  = userRepository.findById(sessionUser .getId());

        if (optionalUser .isPresent()) {
            User existingUser  = optionalUser .get();

            // Update user details
            existingUser .setFullName(updatedUser .getFullName());
            existingUser .setEmail(updatedUser .getEmail());

            // Update password only if provided
            if (updatedUser .getPassword() != null && !updatedUser .getPassword().isEmpty()) {
                existingUser .setPassword(updatedUser .getPassword()); // Set the new password
            }

            // Save the updated user using UserService
            userService.updateUser (existingUser );

            response.put("message", "Profile updated successfully.");
            return ResponseEntity.ok(response);
        } else {
            response.put("error", "User  not found.");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
        }
    }

    // Get all users
    @GetMapping("/users")
    public ResponseEntity<?> getAllUsers() {
        return ResponseEntity.ok(userRepository.findAll());
    }

    // Delete user by ID
    @DeleteMapping("/delete/{id}")
    public ResponseEntity<?> deleteUser(@PathVariable Long id) {
        if (userRepository.existsById(id)) {
            userRepository.deleteById(id);
            return ResponseEntity.ok().build();
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User not found");
    }


}