package Management.com.example.Bicycle.controller;

import Management.com.example.Bicycle.model.RideHistory;
import Management.com.example.Bicycle.service.RideHistoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/rides")
public class RideHistoryController {

    @Autowired
    private RideHistoryService rideHistoryService;

    @PostMapping("/start")
    public ResponseEntity<RideHistory> startRide() {
        try {
            RideHistory ride = rideHistoryService.startRide();
            return ResponseEntity.ok(ride);
        } catch (IllegalStateException e) {
            return ResponseEntity.badRequest().body(null);
        }
    }

    @PutMapping("/stop/{rideId}")
    public ResponseEntity<RideHistory> stopRide(@PathVariable Long rideId) {
        try {
            RideHistory ride = rideHistoryService.stopRide(rideId);
            return ResponseEntity.ok(ride);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(null);
        }
    }

    @GetMapping("/history")
    public ResponseEntity<List<RideHistory>> getUserHistory() {
        try {
            return ResponseEntity.ok(rideHistoryService.getUserHistory());
        } catch (IllegalStateException e) {
            return ResponseEntity.badRequest().body(null);
        }
    }
}