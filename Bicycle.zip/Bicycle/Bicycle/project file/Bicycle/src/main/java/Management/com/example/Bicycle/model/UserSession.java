// UserSession.java
package Management.com.example.Bicycle.model;

import Management.com.example.Bicycle.model.SessionUser ;

public class UserSession {
    private static SessionUser  sessionUser ;

    public static SessionUser  getSessionUser () {
        return sessionUser ;
    }

    public static void setSessionUser (SessionUser  sessionUser ) {
        UserSession.sessionUser  = sessionUser ;
    }

    public static void clearSession() {
        sessionUser  = null; // Clear session on logout
    }
}