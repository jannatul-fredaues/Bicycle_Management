package Management.com.example.Bicycle.model;

import java.text.SimpleDateFormat;
import java.util.*;

class History {
    private String startTime;
    private String endTime;
    private int rideTime;
    private int payment;
    private static final int RATE = 10; // 10 taka per 10 minutes

    public History() {
        this.startTime = "";
        this.endTime = "";
        this.rideTime = 0;
        this.payment = 0;
    }

    public void setStartTime() {
        this.startTime = new SimpleDateFormat("HH:mm dd/MM/yyyy").format(new Date());
    }

    public void setEndTime() {
        this.endTime = new SimpleDateFormat("HH:mm dd/MM/yyyy").format(new Date());
        calculateRideTimeAndPayment();
    }

    private void calculateRideTimeAndPayment() {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("HH:mm dd/MM/yyyy");
            Date start = sdf.parse(startTime);
            Date end = sdf.parse(endTime);
            long diff = end.getTime() - start.getTime();
            this.rideTime = (int) (diff / (1000 * 60)); // Convert milliseconds to minutes
            this.payment = (rideTime / 10) * RATE;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public String getStartTime() { return startTime; }
    public String getEndTime() { return endTime; }
    public int getRideTime() { return rideTime; }
    public int getPayment() { return payment; }
}
