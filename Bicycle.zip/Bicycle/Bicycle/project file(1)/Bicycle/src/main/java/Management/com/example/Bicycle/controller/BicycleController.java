//package Management.com.example.Bicycle.controller;
//
//import Management.com.example.Bicycle.model.Bicycle;
//import org.springframework.web.bind.annotation.*;
//
//import java.util.ArrayList;
//import java.util.List;
//
//@RestController
//@RequestMapping("/bicycles")
//public class BicycleController {
//    private final List<Bicycle> bicycles = new ArrayList<>(60);
//
//    public BicycleController() {
//        // Initializing 60 bicycles
//        for (int i = 0; i < 60; i++) {
//            bicycles.add(new Bicycle());
//        }
//    }
//
//    // Get all bicycles' statuses
//    @GetMapping
//    public List<Bicycle> getAllBicycles() {
//        return bicycles;
//    }
//
//    // Reserve a bicycle by ID
//    @PostMapping("/reserve/{id}")
//    public String reserveBicycle(@PathVariable int id) {
//        if (id < 0 || id >= bicycles.size()) {
//            return "Invalid bicycle ID";
//        }
//        if (bicycles.get(id).reserve()) {
//            return "Bicycle " + id + " reserved successfully!";
//        } else {
//            return "Bicycle " + id + " is not available for reservation.";
//        }
//    }
//
//    // Start a ride with a bicycle by ID
//    @PostMapping("/start/{id}")
//    public String startRide(@PathVariable int id) {
//        if (id < 0 || id >= bicycles.size()) {
//            return "Invalid bicycle ID";
//        }
//        if (bicycles.get(id).startRide()) {
//            return "Ride started with Bicycle " + id + ".";
//        } else {
//            return "Bicycle " + id + " is not available for a ride.";
//        }
//    }
//
//    // End a ride and make the bicycle available again
//    @PostMapping("/end/{id}")
//    public String endRide(@PathVariable int id) {
//        if (id < 0 || id >= bicycles.size()) {
//            return "Invalid bicycle ID";
//        }
//        bicycles.get(id).endRide();
//        return "Bicycle " + id + " ride ended and is now available.";
//    }
//}