//package Management.com.example.Bicycle.controller;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestParam;
//import org.springframework.web.bind.annotation.RestController;
//
//@RestController
//@RequestMapping("/api")
//public class LoginController {
//
//    @Autowired
//    private LoginService loginService;
//
//    @PostMapping("/login")
//    public String loginUser(@RequestParam String email,
//                            @RequestParam String password,
//                            HttpSession session,
//                            Model model) {
//        User user = loginService.findByEmailAndPassword(email, password);
//
//        if (user != null) {
//            session.setAttribute("loggedInUser", user);
//            return "redirect:/student";
//        } else {
//            model.addAttribute("error", "Invalid credentials");
//            return "log_in";
//        }
//    }
//}
//
